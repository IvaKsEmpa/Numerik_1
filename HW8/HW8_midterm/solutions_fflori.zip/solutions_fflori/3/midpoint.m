function int = midpoint(a,b,f)
    int = sum(f)*(b-a)/length(f);
end

